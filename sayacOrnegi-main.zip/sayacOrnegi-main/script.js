function arttir(){
    let sayi=document.getElementById("sayi");
    sayi.value=Number(sayi.value)+1;
}

function azalt(){
    let sayi=document.getElementById("sayi");
    sayi.value=Number(sayi.value)-1;
}

function sifirla(){
    let sayi=document.getElementById("sayi");
    sayi.value=0;
}